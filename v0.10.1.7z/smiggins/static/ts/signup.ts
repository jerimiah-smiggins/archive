inc = 0;

// @ts-ignore
function showlog(str: string, time: number = 3000): void {
  inc++;
  dom("error").innerText = str;
  setTimeout(() => {
    --inc;
    if (!inc) {
      dom("error").innerText = "";
    }
  }, time);
};

dom("toggle-password").addEventListener("click", function(): void {
  if (dom("password").getAttribute("type") == "password") {
    dom("password").setAttribute("type", "text");
    dom("confirm").setAttribute("type", "text");
  } else {
    dom("password").setAttribute("type", "password");
    dom("confirm").setAttribute("type", "password");
  }
});

dom("submit").addEventListener("click", function(): void {
  let username: string = (dom("username") as HTMLInputElement).value;
  let password: string = sha256((dom("password") as HTMLInputElement).value)

  if (password !== sha256((dom("confirm") as HTMLInputElement).value)) {
    showlog(lang.account.password_match_failure);
    return;
  }

  this.setAttribute("disabled", "");
  fetch("/api/user/signup", {
    method: "POST",
    body: JSON.stringify({
      username: username,
      password: password
    })
  })
    .then((response: Response) => {
      if (response.status == 429) {
        dom("post").removeAttribute("disabled");
        dom("post-text").removeAttribute("disabled");
        showlog(lang.generic.ratelimit_verbose);
      } else {
        response.json().then((json: {
          reason: string,
          token: string,
          valid: boolean
        }) => {
          if (json.valid) {
            setCookie("token", json.token);
            window.location.href = "/home";
          } else {
            dom("submit").removeAttribute("disabled");
            showlog(lang.account.sign_up_failure.replaceAll("%s", json.reason));
          }
        });
      }
    })
    .catch((err: Error) => {
      dom("submit").removeAttribute("disabled");
      showlog(lang.generic.something_went_wrong);
    });
});

dom("username").addEventListener("keydown", function(event: KeyboardEvent): void {
  if (event.key == "Enter" || event.keyCode == 18) {
    dom("password").focus();
  }
});

dom("password").addEventListener("keydown", function(event: KeyboardEvent): void {
  if (event.key == "Enter" || event.keyCode == 18) {
    dom("confirm").focus();
  }
});

dom("confirm").addEventListener("keydown", function(event: KeyboardEvent): void {
  if (event.key == "Enter" || event.keyCode == 18) {
    dom("submit").focus();
    dom("submit").click();
  }
});
