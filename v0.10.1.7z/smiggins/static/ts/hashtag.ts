declare let hashtag: string;

home = true;
url = `/api/hashtag/${hashtag}`;
type = "post";
includeUserLink = true;
includePostLink = true;
