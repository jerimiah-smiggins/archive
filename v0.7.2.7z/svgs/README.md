# svgs
this folder isn't needed, however it can be used as a reference.

the following svgs are from fontawesome:
* like-select (`fa-solid fa-heart`)
* like-deselect (`fa-regular fa-heart`)
* settings (`fa-solid fa-gear`)
* home (`fa-solid fa-house`)
* comment (`fa-regular fa-comment`)
* lock (`fa-regular fa-lock`)
* share (`fa-solid fa-share`)
* user (`fa-solid fa-user`)
* quote (`fa-regular fa-quote-left`)
* delete (`fa-regular fa-trash-can`)
* bell (`fa-solid fa-bell`)
