# scripts
this folder is for random one-time scripts that are used when updating from one
version to another, adding something to the database that wasn't there before.
