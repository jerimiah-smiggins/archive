let home = true;

const url = `/api/hashtag/${hashtag}`;
const type = "post";
const includeUserLink = true;
const includePostLink = true;
