# scripts
this folder is for random one-off scripts that are used when updating from one
version to another, adding something to the database that wasn't there before.
these are also all made to work if you paste it into the python3 console.

all of these should be ran in the saving directory (default is `./save`) unless
otherwise specified.

all of these can also be run while the server is running unless otherwise said.
