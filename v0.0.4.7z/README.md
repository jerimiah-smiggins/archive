# social-media-thing
(name and project wip)
## wtf is this and why did you make it
it's like twitter but bad basically, i made it because im really bored

## how to use

run the python file (make sure you have the flask library installed), then go to localhost (specify port if needed), after that everything should work on it's own

---
suggest things under issues
