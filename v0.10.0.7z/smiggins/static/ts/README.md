How to compile the typescript into javascript:
1. install typescript (if you haven't already): `npm i -g typescript`
2. in the root directory of the project, run `tsc`
